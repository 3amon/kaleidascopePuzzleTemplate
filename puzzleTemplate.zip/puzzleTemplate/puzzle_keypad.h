//
// Created by Lasciel on 8/11/2016.
//

#ifndef PUZZLETEMPLATE_PUZZLE_KEYPAD_H
#define PUZZLETEMPLATE_PUZZLE_KEYPAD_H

#include <Arduino.h>

void keyClearData();

char keyCheckForKeyPress();

String keyGetData();

#endif //PUZZLETEMPLATE_PUZZLE_KEYPAD_H
