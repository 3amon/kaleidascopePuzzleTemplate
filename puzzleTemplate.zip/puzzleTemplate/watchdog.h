//
// Created by Lasciel on 8/13/2016.
//

#ifndef PUZZLETEMPLATE_WATCHDOG_H
#define PUZZLETEMPLATE_WATCHDOG_H

bool WatchdogTimerExpired();

void StartWatchdogTimer();

void ResetWatchdogTimer();

void StopWatchdogTimer();

#endif //PUZZLETEMPLATE_WATCHDOG_H
